/*:
## Ejercicio: Crear funciones

 Escribe una función llamada `introduceMyself` (presentarme) que imprima una breve descripción acerca de ti. Llama a la función y observa el resultado.
 */
 

//:  Escribe una función llamada `magicEightBall` (bola 8 mágica) que genere un número aleatorio y luego use una instrucción “switch” o una instrucción “if-else” para imprimir distintas respuestas en función del número aleatorio generado. `let randomNum = Int.random(in: 0...4)` generará un número aleatorio del 0 al 4 y, luego, puedes imprimir distintas frases que correspondan al número generado. Llama a la función varias veces y observa los distintos resultados.
import Foundation


/*:
Página 1 de 6 | [Siguiente: Ejercicio con una app: Una app funcional](@next)
 */