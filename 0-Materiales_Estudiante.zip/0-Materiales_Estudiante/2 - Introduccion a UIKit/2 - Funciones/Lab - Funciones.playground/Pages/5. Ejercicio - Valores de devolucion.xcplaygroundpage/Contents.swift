/*:
## Ejercicio: Valores de devolución

 Escribe una función denominada `greeting` (saludo) que tenga un argumento `String` (cadena) llamado “nombre” y devuelva una `String` que salude al nombre especificado en la función. Por ejemplo, si especificas "Dan", el valor de devolución podría ser "Hola, Dan, ¿cómo estás?”. Usa la función e imprime el resultado.
 */
 

//:  Escribe una función que tenga dos argumentos `Int` (entero) y devuelva un `Int`. La función debe multiplicar los dos argumentos, sumar 2 e imprimir el resultado. Usa la función e imprime el resultado.
 

/*:
[Anterior](@previous) | Página 5 de 6 | [Siguiente: Ejercicio con una app: Separación de funciones](@next)
 */