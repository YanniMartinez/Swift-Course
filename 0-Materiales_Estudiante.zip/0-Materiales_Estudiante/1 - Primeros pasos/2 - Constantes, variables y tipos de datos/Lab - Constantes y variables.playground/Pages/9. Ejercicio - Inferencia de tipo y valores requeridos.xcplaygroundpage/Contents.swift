/*:
## Ejercicio: Inferencia de tipo y valores requeridos
 
 Declara una variable denominada `name` (nombre) de tipo `String` (cadena), pero no le asignes un valor. Imprime `name` en la consola. ¿Se compila el código? Elimina el código que no se compila.
 */
 

//:  Ahora, asígnale un valor a `name` (nombre) e imprímelo en la consola.
 

//:  Declara un valor denominado `distanceTraveled` (distancia recorrida) y configúralo en 0. No le asignes un tipo explícito.
 

//:  Ahora, asígnale un valor de 54.3 a `distanceTraveled` (distancia recorrida). ¿Se compila el código? Regresa y configura un tipo explícito en `distanceTraveled` para que compile el código.
 

/*:
[Anterior](@previous) | Página 9 de 10 | [Siguiente: Ejercicio con una app: Porcentaje completado](@next)
 */