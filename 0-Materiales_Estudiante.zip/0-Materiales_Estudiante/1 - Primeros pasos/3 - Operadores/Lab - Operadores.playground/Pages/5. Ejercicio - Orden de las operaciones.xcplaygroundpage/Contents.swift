/*:
## Ejercicio: Orden de las operaciones

 Imprime el valor que crees que resulta de 10 + 2 * 5. Luego, imprime la expresión real (es decir, `print(10 + 2 * 5)`).
 */
 

//:  En otra instrucción `print`, agrega los paréntesis necesarios para que la suma se realice antes que la multiplicación.
 

//:  Imprime el valor que crees que resulta de 4 * 9 - 6 / 2. Luego, imprime la expresión real.
 

//:  En otra instrucción `print`, agrega los paréntesis necesarios para que se priorice la resta por sobre la multiplicación y la división.
 

/*:
[Anterior](@previous) | Página 5 de 8 | [Siguiente: Ejercicio con una app: Cálculos complejos de actividad física](@next)
 */