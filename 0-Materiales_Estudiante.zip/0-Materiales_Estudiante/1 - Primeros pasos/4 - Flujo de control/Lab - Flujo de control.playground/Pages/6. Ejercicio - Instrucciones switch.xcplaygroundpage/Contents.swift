/*:
## Ejercicio: Instrucciones “switch”
 
 Imagina que estás en un equipo de baseball llegando al final de la temporada. Crea una constante `leaguePosition` (posición en la liga) cuyo valor sea 1. Con una instrucción “switch”, imprime "¡Campeones!" si el valor de `leaguePosition` es 1, "¡Subcampeones!" si el valor es 2, “¡Tercer lugar!” si el valor es 3 y "Mala temporada." en todos los demás casos.
 */
 

//:  Escribe una nueva instrucción “switch” que imprima "Ganadores de medalla" si `leaguePosition` está dentro del rango de 1 a 3. En caso contrario, imprima "No obtuvimos medalla".
 

/*:
[Anterior](@previous) | Página 6 de 9 | [Siguiente: Ejercicio con una app: Niveles deseados de frecuencia cardiaca](@next)
 */