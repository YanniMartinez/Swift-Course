/*:
## Ejercicio: Operador ternario
 
 Refactoriza el código a continuación para que el valor de `largest` (más grande) se declare y se asigne en una línea donde se use un operador ternario.
 */
let number1 = 14
let number2 = 25

var largest: Int
if number1 > number2 {
    largest = number1
} else {
    largest = number2
}
/*:
[Anterior](@previous) | Página 8 de 9 | [Siguiente: Ejercicio con una app: Mensajes ternarios](@next)
 */